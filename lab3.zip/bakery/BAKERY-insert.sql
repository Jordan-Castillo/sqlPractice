/* -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.

* File Name : BAKERY-insert.sql

* Purpose :

* Creation Date : 21-10-2017

* Last Modified : Sat 21 Oct 2017 04:14:54 PM PDT

* Created By : Jordan Castillo

* Email: jtcastil@calpoly.edu 

_._._._._._._._._._._._._._._._._._._._._.*/

SOURCE BAKERY-build-customers.sql

SOURCE BAKERY-build-goods.sql

SOURCE BAKERY-build-receipts.sql

SOURCE BAKERY-build-items.sql
