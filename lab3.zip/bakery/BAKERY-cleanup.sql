/*
	By: Jordan Castillo
	Date: 10 / 2 / 17
	Email: jtcastil@calpoly.edu
	
	BAKERY database cleanup script!
*/
DROP TABLE itemsList;
DROP TABLE receiptsList;
DROP TABLE goodsList;
DROP TABLE customersList;
