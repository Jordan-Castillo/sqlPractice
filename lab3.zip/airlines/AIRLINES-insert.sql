/*\
	Name: Jordan Castillo
	Date: 10 / 21 / 17
	Email: jtcastil@calpoly.edu
\*/

SOURCE AIRLINES-build-airlines.sql

SOURCE AIRLINES-build-airports100.sql

SOURCE AIRLINES-build-flights.sql
