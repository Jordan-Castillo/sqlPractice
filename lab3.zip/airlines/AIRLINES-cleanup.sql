/*
	By: Jordan Castillo
	Date: 10 / 1 / 17
	Email: jtcastil@calpoly.edu
*/

DROP TABLE flightsList;
DROP TABLE airportsList;
DROP TABLE airlinesList;
