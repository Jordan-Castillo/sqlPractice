/* -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.

* File Name : INN-insert.sql

* Purpose :

* Creation Date : 24-10-2017

* Last Modified : Tue 24 Oct 2017 01:03:51 PM DST

* Created By :  Jordan Castillo

* Email : jtcastil@calpoly.edu
_._._._._._._._._._._._._._._._._._._._._.*/
SOURCE INN-build-Rooms.sql

SOURCE INN-build-Reservations.sql
