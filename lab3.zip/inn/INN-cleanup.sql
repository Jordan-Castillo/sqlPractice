/*
	By: Jordan Castillo
	Date: 10 / 2 / 17
	Email: jtcastil@calpoly.edu
	
	INN database cleanup script!
*/
DROP TABLE reservationsList;
DROP TABLE roomsList;
