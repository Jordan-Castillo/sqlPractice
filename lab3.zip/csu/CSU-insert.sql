/* -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.

* File Name : CSU-insert.sql

* Purpose :

* Creation Date : 22-10-2017

* Last Modified : Sun 22 Oct 2017 06:15:32 PM PDT

* Created By : Jordan Castillo

* Email: jtcastil@calpoly.edu 

_._._._._._._._._._._._._._._._._._._._._.*/
SOURCE CSU-build-Campuses.sql

SOURCE CSU-build-disciplines.sql

SOURCE CSU-build-degrees.sql

SOURCE CSU-build-csu-fees.sql

SOURCE CSU-build-discipline-enrollments.sql

SOURCE CSU-build-enrollments.sql

SOURCE CSU-build-faculty.sql
