/*
	By: Jordan Castillo
	Date: 10 / 1 / 17
	Email: jtcastil@calpoly.edu

	CSU database cleaning script
*/
DROP TABLES degreesList,
csuFeesList,
discEnrollList,
enrollmentsList,
facultyList
;
DROP TABLES CampusesList;
DROP TABLES disciplinesList;
