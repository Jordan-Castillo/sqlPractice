/*
	By: Jordan Castillo
	Date: 10 / 2 / 17
	Email: jtcastil@calpoly.edu
	
	KATZENJAMMER database setup script!
*/
DROP TABLE vocalsList;
DROP TABLE tracklistsList;
DROP TABLE performanceList;
DROP TABLE instrumentsList;
DROP TABLE albumsList;
DROP TABLE bandList;
DROP TABLE songsList;
