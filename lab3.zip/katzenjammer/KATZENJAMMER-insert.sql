/* -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.

* File Name : KATZENJAMMER-insert.sql

* Purpose :

* Creation Date : 22-10-2017

* Last Modified : Sun 22 Oct 2017 06:18:45 PM PDT

* Created By : Jordan Castillo

* Email: jtcastil@calpoly.edu 

_._._._._._._._._._._._._._._._._._._._._.*/

SOURCE KATZENJAMMER-build-Songs.sql

SOURCE KATZENJAMMER-build-Band.sql

SOURCE KATZENJAMMER-build-Albums.sql

SOURCE KATZENJAMMER-build-Instruments.sql

SOURCE KATZENJAMMER-build-Performance.sql

SOURCE KATZENJAMMER-build-Tracklists.sql

SOURCE KATZENJAMMER-build-Vocals.sql
