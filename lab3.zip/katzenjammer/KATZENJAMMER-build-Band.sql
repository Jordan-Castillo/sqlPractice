INSERT INTO bandList(bandID, firstName, lastName) VALUES(1, 'Solveig', 'Heilo');
INSERT INTO bandList(bandID, firstName, lastName) VALUES(2, 'Marianne', 'Sveen');
INSERT INTO bandList(bandID, firstName, lastName) VALUES(3, 'Anne-Marit', 'Bergheim');
INSERT INTO bandList(bandID, firstName, lastName) VALUES(4, 'Turid', 'Jorgensen');
